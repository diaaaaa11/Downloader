# ProGuard rules for DirectVideoDownloader
