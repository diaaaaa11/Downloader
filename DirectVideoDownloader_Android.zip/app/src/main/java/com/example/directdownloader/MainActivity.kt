package com.example.directdownloader

import android.Manifest
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var urlEditText: TextInputEditText
    private lateinit var pasteButton: MaterialButton
    private lateinit var downloadButton: MaterialButton
    private lateinit var statusTextView: TextView

    private var activeDownloadId: Long = -1L
    private var pendingUrlForPermission: String? = null
    private var isReceiverRegistered = false

    companion object {
        private const val REQ_LEGACY_STORAGE = 1001

        private val ALLOWED_EXTENSIONS = setOf(
            ".mp4", ".webm", ".mkv", ".mov", ".m4v"
        )

        private val RESTRICTED_STREAMING_DOMAINS = setOf(
            "youtube.com", "youtu.be", "netflix.com", "tiktok.com",
            "instagram.com", "facebook.com", "fb.watch", "vimeo.com",
            "dailymotion.com", "twitch.tv", "twitter.com", "x.com",
            "shahid.mbc.net", "spotify.com"
        )
    }

    private val downloadCompleteReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
            val completedId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (completedId == -1L || completedId != activeDownloadId) return

            verifyDownloadResult(completedId)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlEditText = findViewById(R.id.urlEditText)
        pasteButton = findViewById(R.id.pasteButton)
        downloadButton = findViewById(R.id.downloadButton)
        statusTextView = findViewById(R.id.statusTextView)

        registerDownloadReceiver()

        pasteButton.setOnClickListener {
            pasteFromClipboard()
        }

        downloadButton.setOnClickListener {
            val rawUrl = urlEditText.text?.toString()?.trim().orEmpty()
            validateAndStartDownload(rawUrl)
        }
    }

    private fun registerDownloadReceiver() {
        if (isReceiverRegistered) return
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        ContextCompat.registerReceiver(
            this,
            downloadCompleteReceiver,
            filter,
            ContextCompat.RECEIVER_EXPORTED
        )
        isReceiverRegistered = true
    }

    private fun pasteFromClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val item = clipboard?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)
        val pastedText = item?.coerceToText(this)?.toString()?.trim().orEmpty()

        if (pastedText.isNotEmpty()) {
            urlEditText.setText(pastedText)
            statusTextView.text = "تم لصق الرابط. اضغط على (بدء التنزيل)."
        } else {
            statusTextView.text = "الحافظة فارغة حالياً."
        }
    }

    private fun validateAndStartDownload(rawUrl: String) {
        if (rawUrl.isEmpty()) {
            statusTextView.text = "يرجى لصق رابط ملف فيديو مباشر أولاً."
            return
        }

        val parsedUri = try {
            Uri.parse(rawUrl)
        } catch (e: Exception) {
            statusTextView.text = "صيغة الرابط غير صالحة."
            return
        }

        val scheme = parsedUri.scheme?.lowercase(Locale.ROOT).orEmpty()
        if (scheme != "https" && scheme != "http") {
            statusTextView.text = "يجب أن يبدأ الرابط بـ https:// أو http://"
            return
        }

        val host = parsedUri.host?.lowercase(Locale.ROOT).orEmpty()
        if (host.isEmpty() || isPrivateOrLoopbackHost(host)) {
            statusTextView.text = "نطاق الخادم في الرابط غير صالح للتنزيل العام."
            return
        }

        if (RESTRICTED_STREAMING_DOMAINS.any { host == it || host.endsWith(".$it") }) {
            statusTextView.text = "عذراً، منصات البث المحمية غير مدعومة. يدعم التطبيق روابط ملفات الفيديو المباشرة فقط (.mp4 أو .webm)."
            return
        }

        val path = parsedUri.path?.lowercase(Locale.ROOT).orEmpty()
        val matchedExt = ALLOWED_EXTENSIONS.firstOrNull { path.endsWith(it) }
        if (matchedExt == null) {
            statusTextView.text = "الرابط ليس ملف فيديو مباشراً. تأكد من انتهاء مسار الرابط بـ .mp4 أو .webm أو .mkv أو .mov"
            return
        }

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            val perm = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            if (perm != PackageManager.PERMISSION_GRANTED) {
                pendingUrlForPermission = rawUrl
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    REQ_LEGACY_STORAGE
                )
                return
            }
        }

        enqueueDirectDownload(parsedUri, matchedExt)
    }

    private fun isPrivateOrLoopbackHost(host: String): Boolean {
        return host == "localhost" ||
            host.startsWith("127.") ||
            host.startsWith("10.") ||
            host.startsWith("192.168.") ||
            host.startsWith("169.254.") ||
            host == "::1"
    }

    private fun sanitizeFileName(rawSegment: String?, fallbackExt: String): String {
        val base = rawSegment
            ?.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            ?.trimStart('.')
            ?.take(80)
            .orEmpty()

        if (base.isEmpty()) {
            return "video_${System.currentTimeMillis()}$fallbackExt"
        }
        return if (ALLOWED_EXTENSIONS.any { base.lowercase(Locale.ROOT).endsWith(it) }) {
            base
        } else {
            "$base$fallbackExt"
        }
    }

    private fun enqueueDirectDownload(uri: Uri, ext: String) {
        val safeFileName = sanitizeFileName(uri.lastPathSegment, ext)
        val mimeType = when (ext) {
            ".webm" -> "video/webm"
            ".mkv" -> "video/x-matroska"
            ".mov" -> "video/quicktime"
            else -> "video/mp4"
        }

        try {
            val request = DownloadManager.Request(uri)
                .setTitle(safeFileName)
                .setDescription("جاري تنزيل ملف الفيديو المباشر...")
                .setMimeType(mimeType)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeFileName)

            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            activeDownloadId = dm.enqueue(request)
            statusTextView.text = "بدأ التنزيل إلى مجلد التنزيلات (Downloads):\n$safeFileName"
        } catch (e: Exception) {
            statusTextView.text = "تعذر بدء التنزيل: تحقق من صحة الرابط أو إعدادات مدير التنزيلات."
        }
    }

    private fun verifyDownloadResult(downloadId: Long) {
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager ?: return
        val query = DownloadManager.Query().setFilterById(downloadId)
        var cursor: Cursor? = null
        try {
            cursor = dm.query(query)
            if (cursor != null && cursor.moveToFirst()) {
                val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                if (statusIndex != -1) {
                    when (cursor.getInt(statusIndex)) {
                        DownloadManager.STATUS_SUCCESSFUL -> {
                            statusTextView.text = "اكتمل تنزيل الفيديو بنجاح وحُفظ في مجلد Downloads."
                        }
                        DownloadManager.STATUS_FAILED -> {
                            statusTextView.text = "فشل التنزيل. تأكد من أن الرابط مفتوح ويسمح بالتنزيل المباشر."
                        }
                    }
                }
            }
        } finally {
            cursor?.close()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LEGACY_STORAGE) {
            val savedUrl = pendingUrlForPermission
            pendingUrlForPermission = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && savedUrl != null) {
                validateAndStartDownload(savedUrl)
            } else {
                statusTextView.text = "يلزم منح إذن التخزين على إصدارات أندرويد القديمة لحفظ الفيديو."
            }
        }
    }

    override fun onDestroy() {
        if (isReceiverRegistered) {
            try {
                unregisterReceiver(downloadCompleteReceiver)
            } catch (_: IllegalArgumentException) {
            }
            isReceiverRegistered = false
        }
        super.onDestroy()
    }
}
